(data: Buffer) => {
								console.log('OUTPUT: ' + data.toString());
								this.clients = { ...this.clients, [clientConfig.name]: conn };
								this.io.emit('gotClientConnection', conn);
								var executable = this.commandObject.executable;
								var args = this.commandObject.args;
								conn.exec(
									`${executable} ${args}`,
									(err: Error, stream: any) => {
										if (err) {
											console.log('SECOND :: exec error: ' + err);
											return conn.end();
										}
										stream
											.on('end', () => {
												// Execution and data handling logic
											})
											.on('data', (data: Buffer) => {
												console.log(data.toString());
												console.log('processing output...');
											});
									},
								);
							}