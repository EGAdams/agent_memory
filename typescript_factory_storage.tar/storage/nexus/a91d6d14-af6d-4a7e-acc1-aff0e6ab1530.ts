interface String {
    replaceAll(input: string, output : string): any;
}