log_object => {
            let formatted_time_stamp = new Date( log_object?.timestamp ).toLocaleString()
            let li_inner_html = `
                <div class="log-object-container">
                    <div class="timestamp">${ formatted_time_stamp }</div>
                    <div class="method"   >${ log_object.method    }</div>
                    <div class="message"  >${ log_object.message   }</div>
                </div>`;
            let $new_list_element = document.createElement( 'li' );
            $new_list_element.innerHTML = li_inner_html;
            this.$list_of_log_objects.appendChild( $new_list_element );
        }