interface ClientConfig {
    name: string;
    host: string;
    port?: number;
    username?: string;
    privateKey?: string | Buffer;
}