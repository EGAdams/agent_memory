interface IPopulator {
    populateArray ( data_source: string ): string[]; }