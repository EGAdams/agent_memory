interface ISshConfig {
  name:     string;
  password: string;
  host:     string;
}