interface IQueryRunner {
    runQuery( apiArguments: IApiArgs ): void;
}