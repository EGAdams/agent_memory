interface HTMLElementTagNameMap {
		"inner-component": InnerComponent;
	}