( loggerArg: any ) => {
            this.logger = loggerArg;
            this.logger?.logUpdate( this.constructor.name + "Logger constructed." )
        }