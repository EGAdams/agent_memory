( event: any ) => {
                let accordion_background_element = event.detail.noisy_component.$host.parentElement.previousElementSibling;
                // accordion_background_element.style.display = "block";
                /* change the css style display to "block" using javascript */
                accordion_background_element!.style.display = "block";

                
                if ( !accordion_background_element ) { throw ( Error( "*** ERROR: element not defined! ***" ) ); }
                accordion_background_element.style.backgroundColor = event.detail.monitorLed.classObject.background_color;
                event.detail.noisy_component.$host.parentElement.style.backgroundColor = event.detail.monitorLed.classObject.background_color;
                accordion_background_element.style.color = event.detail.monitorLed.classObject.color;
                event.detail.noisy_component.$host.parentElement.style.color = event.detail.monitorLed.classObject.color;
                let accordion_text_element = event.detail.noisy_component.$host.parentElement.previousElementSibling.firstElementChild.nextElementSibling;
                if ( !accordion_text_element ) { throw ( Error( "*** ERROR: element not defined! ***" ) ); }
                accordion_text_element.innerHTML = event.detail.monitorLed.ledText; }