interface IObserver {
    update(): void;
}