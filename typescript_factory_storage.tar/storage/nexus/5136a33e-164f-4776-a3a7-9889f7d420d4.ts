function (_err: any, result: any, _fields: any) {
                    if (_err) throw _err;
                    console.table( result );
                  }