(err: any, stream: any) => { // Again, consider proper types
                              if (err) {
                                  console.log('SECOND :: exec error: ' + err);
                                  return conn.end();
                              }
                              stream.on('data', (data: any) => console.log(data.toString()));
                          }