() => {
            let accordion_element = this.$host;    
            accordion_element.addEventListener( "click", ( click_event ) => {
                const accordion_section_clicked = click_event.currentTarget as HTMLElement;
                const panel = accordion_section_clicked.shadowRoot?.querySelector<HTMLElement>( ".panel" );
                if ( panel?.style.display === "block" ) {
                    panel.style.display = "none";
                } else {
                    if ( panel ) { panel.style.display = "block"; }}}); }