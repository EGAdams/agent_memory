interface HTMLElementTagNameMap {
		"monitor-led": MonitorLed;
	}