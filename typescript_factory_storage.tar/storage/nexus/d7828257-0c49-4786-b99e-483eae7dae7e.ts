type IApiArgs = {
    thisObject: any;
    trigger: string;  // next function
    query: string;
    data: any;
};