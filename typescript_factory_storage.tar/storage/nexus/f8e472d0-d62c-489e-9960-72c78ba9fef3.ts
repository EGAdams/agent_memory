(error, stdout, stderr) => {
				if (error) {
					console.log(`error in CommandExecutor: ${error.message}`);
					return;
				}
				if (stderr) {
					console.log(`stderr: ${stderr}`);
					return;
				}

				this.commandObject.output = [stdout]; // Assuming output is an array of strings
				console.log('emitting command finished...');
				this.io.emit('commandFinished', this.commandObject);
                console.log( this.commandObject.output );
			}