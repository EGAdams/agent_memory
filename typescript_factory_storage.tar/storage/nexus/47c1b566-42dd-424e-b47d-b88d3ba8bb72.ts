interface IQueryResultProcessor {
    processQueryResult( queryResultToBeProcessed: any ): void; }