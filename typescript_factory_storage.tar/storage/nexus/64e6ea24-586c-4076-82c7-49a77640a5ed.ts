interface HTMLElementTagNameMap {
		"log-object": LogObject;
	}