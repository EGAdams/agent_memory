interface IMonitorLedClassObject {
  background_color :string;
  text_align       :string;
  margin_top       :string;
  color            :string;
}