interface DataEventCallbackParameter {
    // Define the structure here. As an example:
    // data: string;
}