(err: any, stream: { on: (arg0: string, arg1: { (): void; (data: any): void; }) => void; }) => {
                if (err) throw err;
                stream.on("close", () => {
                    console.log("Stream :: close");
                    conn.end();
                });

                stream.on("data", ( data?: any ) => {
                    console.log(`OUTPUT: ${data}`);
                    // self.clients[clientConfig.name] = conn;
                    // self.emitter.emit("gotClientConnection", conn);
                    conn.exec("ls -lart", (err: any, stream: any) => {
                        if (err) {
                          console.log(`SECOND :: exec error: ${err}`);
                          return conn.end();
                        }
                        stream.on("end", () => {
                          // conn.end(); // close parent (and this) connection
                        });
                        stream.on("data", (data: any) => {
                          console.log(data.toString());
                          console.log("processing output...");
                          self.clients[clientConfig.name] = conn;
                        });
                      });
                      
                  });
                //stream.end('./alertCheck.sh\n./blotterCheck.sh\nexit\n');
            }