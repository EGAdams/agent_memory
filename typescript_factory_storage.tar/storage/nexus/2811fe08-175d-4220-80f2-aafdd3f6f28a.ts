res => {
                return res.text();
            }