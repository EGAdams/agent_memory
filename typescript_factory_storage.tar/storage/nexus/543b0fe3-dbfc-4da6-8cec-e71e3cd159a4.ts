class MonitoredObjectsTableInserter {

    constructor() { console.log( 'constructing MonitoredObjectsTableInserter object...' ); }
    queryInsertProcessor = new QueryInsertProcessor();
    insertMonitoredObject ( object_view_id: string, object_data: string ): void {
        const args: IApiArgs  = {
            query: "insert into monitored_objects( object_view_id, object_data ) values ( '"
                + object_view_id + "', '" + object_data + "' )",
            data: {},
            queryResultProcessor: this.queryInsertProcessor
        }
        console.log( "running query: " + args.query );
        // this.dataSource.runQuery( args );
    }
}