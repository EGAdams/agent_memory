function (_err: any, delete_result: any, _fields: any) {
                    if (_err) throw _err;
                    console.table( delete_result );
                    callback( delete_result );
                  }