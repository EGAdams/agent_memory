interface IDataObject {
    runQuery( apiArgs: any ): void;
}