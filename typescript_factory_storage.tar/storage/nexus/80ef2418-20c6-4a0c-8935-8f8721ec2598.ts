function (_err, result, _fields) {
				if (_err) throw _err;
				console.table( result );
				// callback( result );
				}