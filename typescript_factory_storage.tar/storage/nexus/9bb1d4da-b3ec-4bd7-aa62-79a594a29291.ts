() => { 
            // console.log( "refreshing logs... " );
            this.logObjectContainerSource.refresh();
            this.logs = this.logObjectContainerSource.logObjectProcessor.getWrittenLogs(); }