function wrap ( importComponent: () => Promise<any>, className: string, observedAttributes: Array< string > ) {
    
    class CustomComponent extends HTMLElement {

        private _newComponentInstance: IWebComponentDecorated = {} as IWebComponentDecorated;
        private _connected = false;
        private _componentConstructor: OriginalComponentClassType = {} as OriginalComponentClassType;
        private _changedAttributes = false;
        private _attrArr: Array< AttributeValue > = [];

        static originalObservedAttributes: any;

        static get observedAttributes (): Array< string > { return observedAttributes; }

        constructor() {
            super();
            const shadow = this.attachShadow({ mode: 'open' });
            importComponent().then(( component ) => {
                this._componentConstructor = component[ className ];
                this._newComponentInstance = new this._componentConstructor( shadow, shadow.host );
                this._componentConstructor.prototype?.properties?.forEach(( componentPrototypeProperty: string ) => {
                    Object.defineProperty( this, componentPrototypeProperty, {
                        get: (     ) => { return ( this._newComponentInstance as any )[ componentPrototypeProperty ]      ; },
                        set: ( val ) => { (        this._newComponentInstance as any )[ componentPrototypeProperty ] = val; },
                    }); });

                shadow.innerHTML = this._newComponentInstance!.sourceHtmlText;
                const firstChild = shadow.firstChild;

                const styleTag = document.createElement( 'style' ) ;
                styleTag.innerHTML = this._newComponentInstance?.sourceStyleText;

                shadow.insertBefore( styleTag, firstChild );

                if ( this._connected ) {
                    this._newComponentInstance.connectedCallback();
                    if ( !this._changedAttributes ) {
                        this._attrArr.forEach(( attr: AttributeValue ) => this._newComponentInstance?.attributeChangedCallback( attr.name, attr.oldValue, attr.newValue ) );
                        this._changedAttributes = true;
                    }
                }
                this.dispatchEvent( new Event( 'ready' ) );
            });
        }

        connectedCallback() {    this._connected = true;                             }
        disconnectedCallback() { this._newComponentInstance?.disconnectedCallback(); }
        adoptedCallback () {     this._newComponentInstance?.adoptedCallback();      }

        attributeChangedCallback ( name: string, oldValue: any, newValue: any ) {
            if ( !this._changedAttributes ) {
                this._attrArr.push({ name, oldValue, newValue });
            }
            else {
                this._newComponentInstance?.attributeChangedCallback( name, oldValue, newValue );
            }
        }
    }
    return CustomComponent; }