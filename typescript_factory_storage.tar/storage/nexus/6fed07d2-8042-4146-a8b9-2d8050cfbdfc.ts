interface HTMLElementTagNameMap {
		"accordion-section": AccordionSection;
	}