interface IMonitoredObjectConfig {
	new_id               :string;
	data_source_location :string;
}