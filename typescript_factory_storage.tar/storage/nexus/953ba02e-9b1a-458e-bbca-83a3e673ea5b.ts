interface ISourceQueryConfig {
  object_view_id :string;
  object_data    :any;
}