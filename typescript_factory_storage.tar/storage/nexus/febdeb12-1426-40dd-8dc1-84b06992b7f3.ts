data => {
                callbackObject.processQueryResult( callbackObject, data );
            }