class TheEmitter extends EventEmitter {
  constructor() {
    super();
  }

  foo(): void {
    this.emit('test');
  }
}