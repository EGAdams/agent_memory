class MonitorLedClassObject {
    background_color: string;
    text_align: string;
    margin_top: string;
    color: string;

    constructor() {
        this.background_color = "lightyellow";
        this.text_align       = "left";
        this.margin_top       = "2px";
        this.color            = "black"; }
}