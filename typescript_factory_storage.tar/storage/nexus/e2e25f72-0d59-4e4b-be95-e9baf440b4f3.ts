( component ) => {
                this._componentConstructor = component[ className ];
                this._newComponentInstance = new this._componentConstructor( shadow, shadow.host );
                this._componentConstructor.prototype?.properties?.forEach(( componentPrototypeProperty: string ) => {
                    Object.defineProperty( this, componentPrototypeProperty, {
                        get: (     ) => { return ( this._newComponentInstance as any )[ componentPrototypeProperty ]      ; },
                        set: ( val ) => { (        this._newComponentInstance as any )[ componentPrototypeProperty ] = val; },
                    }); });

                shadow.innerHTML = this._newComponentInstance!.sourceHtmlText;
                const firstChild = shadow.firstChild;

                const styleTag = document.createElement( 'style' ) ;
                styleTag.innerHTML = this._newComponentInstance?.sourceStyleText;

                shadow.insertBefore( styleTag, firstChild );

                if ( this._connected ) {
                    this._newComponentInstance.connectedCallback();
                    if ( !this._changedAttributes ) {
                        this._attrArr.forEach(( attr: AttributeValue ) => this._newComponentInstance?.attributeChangedCallback( attr.name, attr.oldValue, attr.newValue ) );
                        this._changedAttributes = true;
                    }
                }
                this.dispatchEvent( new Event( 'ready' ) );
            }