class TableManager {
    // dataSource: IDataObject;
    subjects: Array< ISubject > = [];

    constructor() {
        // this.dataSource = DataSourceFactory.getDataSource();
    }

    createObjectRow ( object_id: string ): void {
        const nextFunction = "checkResults";
        // create a new row in the monitored objects table  
    }

    checkResults (
        _event: unknown,
        results: { data: { error: string | string[] }; query: string }
    ): void {
        console.log(
            "checking results of table manager inserting new object row... "
        );
        if ( results.data.error ) {
            if ( results.data.error.includes( "Duplicate entry" ) ) {
                console.log(
                    "*** WARNING: duplicate entry in monitored objects table. ***"
                );
            } else {
                console.error(
                    "*** ERROR: while running query: " + results.query + " ***"
                );
            }
        }
    }
}