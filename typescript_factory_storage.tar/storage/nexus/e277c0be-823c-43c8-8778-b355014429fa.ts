interface HTMLElementTagNameMap {
		"log-viewer": LogViewer;
	}