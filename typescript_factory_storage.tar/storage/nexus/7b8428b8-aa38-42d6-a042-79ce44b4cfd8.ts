class JewelryMachineQueryRunner implements IQueryRunner, ITestable {
    url = "http://americansjewelry.com/test2/runQuery.php";

    constructor() { console.log( 'constructing JewelryMachineQueryRunner object...' ); }

    /**
     *
     *
     * @param {IApiArgs} apiArguments
     * @return {*}  {Promise<void>}
     * @memberof JewelryMachineQueryRunner
     */
    async runQuery ( apiArguments: IApiArgs ): Promise< void > {
        // const queryResults = await axios.get( this.url, { params: { sql: apiArguments.query } } );
        // apiArguments.queryResultProcessor.processQueryResult( queryResults );
    }
    
    /**
     *
     *
     * @memberof JewelryMachineQueryRunner
     */
    testMe (): void {
        // const test = new JewelryMachineQueryRunnerTest( this );
        // test.run();
    }
}