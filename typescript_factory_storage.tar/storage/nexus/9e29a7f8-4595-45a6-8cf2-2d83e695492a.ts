(data: any) => {
                          console.log(data.toString());
                          console.log("processing output...");
                          self.clients[clientConfig.name] = conn;
                        }