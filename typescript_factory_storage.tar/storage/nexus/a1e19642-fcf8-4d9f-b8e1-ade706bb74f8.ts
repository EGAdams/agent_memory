interface IApiArgs {
    data: unknown;
    queryResultProcessor: IQueryProcessor;
    query: string;
}