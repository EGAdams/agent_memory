interface IMonitorLedData {
  classObject :IMonitorLedClassObject;
  ledText     :string;
}