interface IRawRegexStringPair {
  name: string;
  regex_string: string;
}