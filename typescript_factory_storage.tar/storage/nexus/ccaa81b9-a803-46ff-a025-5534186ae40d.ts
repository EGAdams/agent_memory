interface INameRegexPair {
  name: string;
  regex: RegExpMatchArray;
}