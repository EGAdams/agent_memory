interface HTMLElementTagNameMap {
		"hello-world": HelloWorld;
	}