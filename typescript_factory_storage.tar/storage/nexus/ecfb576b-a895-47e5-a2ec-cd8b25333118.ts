interface ILogObject {
	id: string;
	timestamp: number; // timestamp in milliseconds since epoch
	message: string;
	method: string;
}