(err: any, stream: any) => {
                        if (err) {
                          console.log(`SECOND :: exec error: ${err}`);
                          return conn.end();
                        }
                        stream.on("end", () => {
                          // conn.end(); // close parent (and this) connection
                        });
                        stream.on("data", (data: any) => {
                          console.log(data.toString());
                          console.log("processing output...");
                          self.clients[clientConfig.name] = conn;
                        });
                      }