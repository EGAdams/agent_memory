( componentPrototypeProperty: string ) => {
                    Object.defineProperty( this, componentPrototypeProperty, {
                        get: (     ) => { return ( this._newComponentInstance as any )[ componentPrototypeProperty ]      ; },
                        set: ( val ) => { (        this._newComponentInstance as any )[ componentPrototypeProperty ] = val; },
                    }); }