class CommandExecutorLogger extends MonitoredObject {
	constructor(config: IMonitoredObjectConfig) { super(config); }
 }