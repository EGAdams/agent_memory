interface IQueryResultProcessor {
    /**
     * Processes the given query result.
     * 
     * @param thisObject - The instance of the query result processor.
     * @param queryResultToBeProcessed - The query result to be processed.
     */
    processQueryResult(thisObject: IQueryResultProcessor, queryResultToBeProcessed: any): void;
}