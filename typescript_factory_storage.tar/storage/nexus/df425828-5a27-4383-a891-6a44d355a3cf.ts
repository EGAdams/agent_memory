interface IRegex {
  matchedString( line: string ): boolean | INameRegexPair;
}