() => {
            console.log('Client :: ready');
            conn.shell((err: any, stream: any) => { // Consider defining proper types for err and stream
                if (err) throw err;
                stream.on('close', () => console.log('Stream :: close'))
                      .on('data', (data: any) => { // Consider defining proper types for data
                          console.log('OUTPUT: ' + data);
                          this.clients[clientConfig.name] = conn;
                          this.emitter.emit('gotClientConnection', conn);
                          conn.exec('ls -lart', (err: any, stream: any) => { // Again, consider proper types
                              if (err) {
                                  console.log('SECOND :: exec error: ' + err);
                                  return conn.end();
                              }
                              stream.on('data', (data: any) => console.log(data.toString()));
                          });
                      });
            });
        }