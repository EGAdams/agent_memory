interface ITestable {
    testMe(): void;
}